# Ƙalize Recorder — Android recording milestone (v1)

This update adds a native Android MediaProjection screen-recording implementation to the starter project.

## Included
- Android system consent prompt before screen capture.
- Foreground service marked as `mediaProjection`.
- Video-only MP4 recording (H.264) at a selected target size and 30 or 60 FPS.
- Stop action and ongoing notification.
- Android 10+ saves to `Movies/Kalize Recorder` using MediaStore. Android 8–9 saves under the app-specific Movies folder.
- Existing web dashboard prototype, if included.

## Important
This is source code, not a prebuilt APK. It has not been compiled or device-tested in this environment. You need a compatible Android build environment to build/install it. With a phone only, you can try an on-device Android development environment, but compatibility and setup may vary. AndroidIDE's original project was archived, so verify any tooling is still maintained before installing it.

## Build/use
1. Extract this ZIP to a folder on your phone.
2. Open the `android` directory in an Android development environment that supports Gradle/Android SDK.
3. Let Gradle sync and resolve dependencies.
4. Build and install the debug app on your own phone.
5. Open Ƙalize Recorder and tap **Start recording**.
6. Approve Android's screen-capture prompt. Android displays its recording/foreground-service indicators.
7. Tap **Stop recording** inside the app. Find the MP4 in `Movies/Kalize Recorder` on Android 10+.

## Limitations of this milestone
- Video only; no microphone or internal audio capture yet.
- Resolution selection is a target long-edge size; device limits and aspect ratio can affect the result.
- FPS is set to 30 or 60 as a target, not guaranteed. Some devices may reject unsupported combinations.
- Floating bubble, screenshots, editing/export, CPU benchmark, network test, and game booster are not connected yet.
- Apps and protected content may block capture or produce black areas. Users can stop screen sharing at any time.
